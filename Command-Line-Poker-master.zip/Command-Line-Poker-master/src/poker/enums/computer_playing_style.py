from enum import Enum, auto


class ComputerPlayingStyle(Enum):
    SAFE = auto()
    RISKY = auto()
    RANDOM = auto()
